// Opens the one upstream source link this recheck added to the troubleshooting document and confirms the page shows
// the quoted line, then closes the browser. Prints one JSON line.
//
// Run: node verify-new-link.ts > keep/verify-new-link.jsonl

import { spawnSync, } from 'node:child_process';

const URL = 'https://github.com/dahlia/optique/blob/d26f1a244d4434f9dbfeb0317f6db32533cb8c32/packages/core/src/primitives.ts#L1251';
const EXPECT = ['buffer: context.buffer.slice(2),',];

function browser(args: string[],): string {
  const child = spawnSync('agent-browser', args, { encoding: 'utf8', maxBuffer: 64 * 1024 * 1024, timeout: 120000, },);

  return `${child.stdout}${child.stderr}`;
}

browser(['open', URL,],);
browser(['wait', '4000',],);

const flat = browser(['eval', 'document.body.innerText',],).replace(/\\n/gu, ' ',).replace(/\\"/gu, '"',).replace(/\s+/gu, ' ',);
// The line the link selects, read from the page's own highlight when the page marks one.
const selected = browser(['eval', "[...document.querySelectorAll('.highlighted-line, .react-code-line-contents.highlighted, [data-line-number=\"1251\"]')].map((node) => node.textContent ?? node.getAttribute('data-line-number')).join(' | ').slice(0, 300)",],).trim();

console.log(JSON.stringify({ url: URL, found: EXPECT.map((needle,) => flat.includes(needle,)), has1251: flat.includes('1251',), selected, length: flat.length, },),);
console.log(browser(['close',],).trim(),);
