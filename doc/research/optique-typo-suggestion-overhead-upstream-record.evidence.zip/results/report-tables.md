## Measured spread of an unchanged arm

- `1.3.6` issue988 issue988 n=1000: 
8 copies, median 106.44 ms, range 5.29 ms (5.0%)
- `1.3.6` no-separator real n=1: 
8 copies, median 0.96 ms, range 0.16 ms (16.9%)
- `1.3.6` no-separator real n=10: 
8 copies, median 2.43 ms, range 0.38 ms (15.5%)
- `1.3.6` no-separator real n=100: 
8 copies, median 23.43 ms, range 2.26 ms (9.7%)
- `1.3.6` no-separator real n=1000: 
8 copies, median 184.26 ms, range 6.61 ms (3.6%)
- `1.4.0-dev.2971` no-separator real n=1000: 
8 copies, median 93.04 ms, range 10.21 ms (11.0%)
- `owned-4879a44e` no-separator real n=1000: 
8 copies, median 0.17 ms, range 0.03 ms (15.2%)
- `1.3.6` no-separator short n=1000: 
8 copies, median 188.67 ms, range 13.41 ms (7.1%)

## issue988 1000

Measured medians, with the range of every timed sample:

- `1.1.1`: median 964.256 ms (min 924.540 ms, max 1299.860 ms, 49 timed parses)
- `1.3.1`: median 952.035 ms (min 895.359 ms, max 1211.733 ms, 49 timed parses)
- `1.3.2`: median 111.092 ms (min 98.691 ms, max 150.827 ms, 49 timed parses)
- `1.3.6`: median 109.276 ms (min 97.157 ms, max 172.948 ms, 49 timed parses)
- `1.4.0-dev.2664`: median 147.783 ms (min 130.492 ms, max 218.479 ms, 49 timed parses)
- `1.4.0-dev.2665`: median 83.019 ms (min 73.744 ms, max 104.579 ms, 49 timed parses)
- `1.4.0-dev.2667`: median 80.300 ms (min 74.401 ms, max 110.914 ms, 49 timed parses)
- `1.4.0-dev.2971`: median 86.209 ms (min 72.363 ms, max 145.752 ms, 49 timed parses)
- `owned-4879a44e`: not measured

Noise threshold from unchanged arms for this cell: 16.9% (nearest measured configuration, not this cell)

- `1.1.1` to `1.3.1` (before the 1.3.2 patch): 964.256 ms to 952.035 ms, -1.3%, within noise
- `1.3.1` to `1.3.2` (the 1.3.2 patch (pull 992)): 952.035 ms to 111.092 ms, -88.3%, beyond noise
- `1.3.2` to `1.3.6` (three later 1.3 maintenance releases): 111.092 ms to 109.276 ms, -1.6%, within noise
- `1.3.6` to `1.4.0-dev.2664` (last dev build before pull 997): 109.276 ms to 147.783 ms, 35.2%, beyond noise
- `1.4.0-dev.2664` to `1.4.0-dev.2665` (pull 997 (deferred diagnostics)): 147.783 ms to 83.019 ms, -43.8%, beyond noise
- `1.4.0-dev.2665` to `1.4.0-dev.2667` (the pull-997 merge commit): 83.019 ms to 80.300 ms, -3.3%, within noise
- `1.4.0-dev.2667` to `1.4.0-dev.2971` (main since 2667 up to current dev): 80.300 ms to 86.209 ms, 7.4%, within noise

## no-separator real 1 n=1

Measured medians, with the range of every timed sample:

- `1.1.1`: median 2.749 ms (min 2.376 ms, max 4.701 ms, 49 timed parses), 72.3x the owned parser
- `1.3.1`: median 2.997 ms (min 2.525 ms, max 6.226 ms, 49 timed parses), 78.9x the owned parser
- `1.3.2`: median 0.867 ms (min 0.620 ms, max 2.586 ms, 49 timed parses), 22.8x the owned parser
- `1.3.6`: median 1.025 ms (min 0.658 ms, max 2.126 ms, 49 timed parses), 27.0x the owned parser
- `1.4.0-dev.2664`: median 1.089 ms (min 0.728 ms, max 2.972 ms, 49 timed parses), 28.7x the owned parser
- `1.4.0-dev.2665`: median 0.791 ms (min 0.405 ms, max 1.766 ms, 49 timed parses), 20.8x the owned parser
- `1.4.0-dev.2667`: median 0.743 ms (min 0.408 ms, max 1.618 ms, 49 timed parses), 19.6x the owned parser
- `1.4.0-dev.2971`: median 0.526 ms (min 0.414 ms, max 1.871 ms, 49 timed parses), 13.8x the owned parser
- `owned-4879a44e`: median 0.038 ms (min 0.018 ms, max 0.081 ms, 49 timed parses)

Noise threshold from unchanged arms for this cell: 16.9%

- `1.1.1` to `1.3.1` (before the 1.3.2 patch): 2.749 ms to 2.997 ms, 9.0%, within noise
- `1.3.1` to `1.3.2` (the 1.3.2 patch (pull 992)): 2.997 ms to 0.867 ms, -71.1%, beyond noise
- `1.3.2` to `1.3.6` (three later 1.3 maintenance releases): 0.867 ms to 1.025 ms, 18.2%, beyond noise
- `1.3.6` to `1.4.0-dev.2664` (last dev build before pull 997): 1.025 ms to 1.089 ms, 6.3%, within noise
- `1.4.0-dev.2664` to `1.4.0-dev.2665` (pull 997 (deferred diagnostics)): 1.089 ms to 0.791 ms, -27.4%, beyond noise
- `1.4.0-dev.2665` to `1.4.0-dev.2667` (the pull-997 merge commit): 0.791 ms to 0.743 ms, -6.1%, within noise
- `1.4.0-dev.2667` to `1.4.0-dev.2971` (main since 2667 up to current dev): 0.743 ms to 0.526 ms, -29.2%, beyond noise

## no-separator real 10 n=10

Measured medians, with the range of every timed sample:

- `1.1.1`: median 21.479 ms (min 20.549 ms, max 26.046 ms, 49 timed parses), 671.2x the owned parser
- `1.3.1`: median 21.770 ms (min 20.687 ms, max 34.848 ms, 49 timed parses), 680.3x the owned parser
- `1.3.2`: median 2.658 ms (min 1.976 ms, max 4.794 ms, 49 timed parses), 83.1x the owned parser
- `1.3.6`: median 2.486 ms (min 1.943 ms, max 8.081 ms, 49 timed parses), 77.7x the owned parser
- `1.4.0-dev.2664`: median 3.457 ms (min 2.515 ms, max 7.501 ms, 49 timed parses), 108.0x the owned parser
- `1.4.0-dev.2665`: median 1.685 ms (min 0.961 ms, max 5.059 ms, 49 timed parses), 52.6x the owned parser
- `1.4.0-dev.2667`: median 1.700 ms (min 0.959 ms, max 3.619 ms, 49 timed parses), 53.1x the owned parser
- `1.4.0-dev.2971`: median 2.146 ms (min 1.024 ms, max 3.893 ms, 49 timed parses), 67.0x the owned parser
- `owned-4879a44e`: median 0.032 ms (min 0.022 ms, max 0.088 ms, 49 timed parses)

Noise threshold from unchanged arms for this cell: 15.5%

- `1.1.1` to `1.3.1` (before the 1.3.2 patch): 21.479 ms to 21.770 ms, 1.4%, within noise
- `1.3.1` to `1.3.2` (the 1.3.2 patch (pull 992)): 21.770 ms to 2.658 ms, -87.8%, beyond noise
- `1.3.2` to `1.3.6` (three later 1.3 maintenance releases): 2.658 ms to 2.486 ms, -6.5%, within noise
- `1.3.6` to `1.4.0-dev.2664` (last dev build before pull 997): 2.486 ms to 3.457 ms, 39.1%, beyond noise
- `1.4.0-dev.2664` to `1.4.0-dev.2665` (pull 997 (deferred diagnostics)): 3.457 ms to 1.685 ms, -51.3%, beyond noise
- `1.4.0-dev.2665` to `1.4.0-dev.2667` (the pull-997 merge commit): 1.685 ms to 1.700 ms, 0.9%, within noise
- `1.4.0-dev.2667` to `1.4.0-dev.2971` (main since 2667 up to current dev): 1.700 ms to 2.146 ms, 26.2%, beyond noise

## no-separator real 100 n=100

Measured medians, with the range of every timed sample:

- `1.1.1`: median 150.104 ms (min 143.594 ms, max 224.193 ms, 49 timed parses), 3008.1x the owned parser
- `1.3.1`: median 151.129 ms (min 141.251 ms, max 201.750 ms, 49 timed parses), 3028.6x the owned parser
- `1.3.2`: median 24.898 ms (min 21.592 ms, max 48.342 ms, 49 timed parses), 499.0x the owned parser
- `1.3.6`: median 23.414 ms (min 21.418 ms, max 32.724 ms, 49 timed parses), 469.2x the owned parser
- `1.4.0-dev.2664`: median 27.585 ms (min 24.805 ms, max 35.297 ms, 49 timed parses), 552.8x the owned parser
- `1.4.0-dev.2665`: median 9.624 ms (min 7.954 ms, max 14.137 ms, 49 timed parses), 192.9x the owned parser
- `1.4.0-dev.2667`: median 10.410 ms (min 7.739 ms, max 32.597 ms, 49 timed parses), 208.6x the owned parser
- `1.4.0-dev.2971`: median 10.389 ms (min 7.813 ms, max 16.404 ms, 49 timed parses), 208.2x the owned parser
- `owned-4879a44e`: median 0.050 ms (min 0.034 ms, max 0.104 ms, 49 timed parses)

Noise threshold from unchanged arms for this cell: 9.7%

- `1.1.1` to `1.3.1` (before the 1.3.2 patch): 150.104 ms to 151.129 ms, 0.7%, within noise
- `1.3.1` to `1.3.2` (the 1.3.2 patch (pull 992)): 151.129 ms to 24.898 ms, -83.5%, beyond noise
- `1.3.2` to `1.3.6` (three later 1.3 maintenance releases): 24.898 ms to 23.414 ms, -6.0%, within noise
- `1.3.6` to `1.4.0-dev.2664` (last dev build before pull 997): 23.414 ms to 27.585 ms, 17.8%, beyond noise
- `1.4.0-dev.2664` to `1.4.0-dev.2665` (pull 997 (deferred diagnostics)): 27.585 ms to 9.624 ms, -65.1%, beyond noise
- `1.4.0-dev.2665` to `1.4.0-dev.2667` (the pull-997 merge commit): 9.624 ms to 10.410 ms, 8.2%, within noise
- `1.4.0-dev.2667` to `1.4.0-dev.2971` (main since 2667 up to current dev): 10.410 ms to 10.389 ms, -0.2%, within noise

## no-separator real 1000 n=1000

Measured medians, with the range of every timed sample:

- `1.1.1`: median 2695.663 ms (min 2574.641 ms, max 3898.915 ms, 49 timed parses), 15281.5x the owned parser
- `1.3.1`: median 2706.689 ms (min 2570.456 ms, max 2985.197 ms, 49 timed parses), 15344.0x the owned parser
- `1.3.2`: median 180.033 ms (min 166.344 ms, max 206.032 ms, 49 timed parses), 1020.6x the owned parser
- `1.3.6`: median 184.275 ms (min 172.846 ms, max 228.530 ms, 49 timed parses), 1044.6x the owned parser
- `1.4.0-dev.2664`: median 229.046 ms (min 206.594 ms, max 294.573 ms, 49 timed parses), 1298.4x the owned parser
- `1.4.0-dev.2665`: median 90.195 ms (min 80.496 ms, max 115.034 ms, 49 timed parses), 511.3x the owned parser
- `1.4.0-dev.2667`: median 96.813 ms (min 84.447 ms, max 114.766 ms, 49 timed parses), 548.8x the owned parser
- `1.4.0-dev.2971`: median 94.962 ms (min 83.552 ms, max 242.640 ms, 49 timed parses), 538.3x the owned parser
- `owned-4879a44e`: median 0.176 ms (min 0.089 ms, max 1.319 ms, 49 timed parses)

Noise threshold from unchanged arms for this cell: 15.2%

- `1.1.1` to `1.3.1` (before the 1.3.2 patch): 2695.663 ms to 2706.689 ms, 0.4%, within noise
- `1.3.1` to `1.3.2` (the 1.3.2 patch (pull 992)): 2706.689 ms to 180.033 ms, -93.3%, beyond noise
- `1.3.2` to `1.3.6` (three later 1.3 maintenance releases): 180.033 ms to 184.275 ms, 2.4%, within noise
- `1.3.6` to `1.4.0-dev.2664` (last dev build before pull 997): 184.275 ms to 229.046 ms, 24.3%, beyond noise
- `1.4.0-dev.2664` to `1.4.0-dev.2665` (pull 997 (deferred diagnostics)): 229.046 ms to 90.195 ms, -60.6%, beyond noise
- `1.4.0-dev.2665` to `1.4.0-dev.2667` (the pull-997 merge commit): 90.195 ms to 96.813 ms, 7.3%, within noise
- `1.4.0-dev.2667` to `1.4.0-dev.2971` (main since 2667 up to current dev): 96.813 ms to 94.962 ms, -1.9%, within noise

## no-separator short 1 n=1

Measured medians, with the range of every timed sample:

- `1.1.1`: median 0.737 ms (min 0.633 ms, max 1.508 ms, 49 timed parses), 18.5x the owned parser
- `1.3.1`: median 0.856 ms (min 0.685 ms, max 1.611 ms, 49 timed parses), 21.5x the owned parser
- `1.3.2`: median 0.972 ms (min 0.641 ms, max 3.560 ms, 49 timed parses), 24.4x the owned parser
- `1.3.6`: median 0.911 ms (min 0.632 ms, max 2.242 ms, 49 timed parses), 22.9x the owned parser
- `1.4.0-dev.2664`: median 1.032 ms (min 0.709 ms, max 2.189 ms, 49 timed parses), 25.9x the owned parser
- `1.4.0-dev.2665`: median 0.803 ms (min 0.452 ms, max 3.090 ms, 49 timed parses), 20.2x the owned parser
- `1.4.0-dev.2667`: median 0.741 ms (min 0.447 ms, max 1.409 ms, 49 timed parses), 18.6x the owned parser
- `1.4.0-dev.2971`: median 0.784 ms (min 0.419 ms, max 1.562 ms, 49 timed parses), 19.7x the owned parser
- `owned-4879a44e`: median 0.040 ms (min 0.017 ms, max 0.122 ms, 49 timed parses)

Noise threshold from unchanged arms for this cell: 7.1% (nearest measured configuration, not this cell)

- `1.1.1` to `1.3.1` (before the 1.3.2 patch): 0.737 ms to 0.856 ms, 16.2%, beyond noise
- `1.3.1` to `1.3.2` (the 1.3.2 patch (pull 992)): 0.856 ms to 0.972 ms, 13.5%, beyond noise
- `1.3.2` to `1.3.6` (three later 1.3 maintenance releases): 0.972 ms to 0.911 ms, -6.2%, within noise
- `1.3.6` to `1.4.0-dev.2664` (last dev build before pull 997): 0.911 ms to 1.032 ms, 13.3%, beyond noise
- `1.4.0-dev.2664` to `1.4.0-dev.2665` (pull 997 (deferred diagnostics)): 1.032 ms to 0.803 ms, -22.2%, beyond noise
- `1.4.0-dev.2665` to `1.4.0-dev.2667` (the pull-997 merge commit): 0.803 ms to 0.741 ms, -7.8%, beyond noise
- `1.4.0-dev.2667` to `1.4.0-dev.2971` (main since 2667 up to current dev): 0.741 ms to 0.784 ms, 5.9%, within noise

## no-separator short 10 n=10

Measured medians, with the range of every timed sample:

- `1.1.1`: median 2.959 ms (min 2.583 ms, max 7.470 ms, 49 timed parses), 89.1x the owned parser
- `1.3.1`: median 3.159 ms (min 2.718 ms, max 4.777 ms, 49 timed parses), 95.1x the owned parser
- `1.3.2`: median 2.322 ms (min 1.981 ms, max 9.585 ms, 49 timed parses), 69.9x the owned parser
- `1.3.6`: median 2.322 ms (min 1.920 ms, max 4.453 ms, 49 timed parses), 69.9x the owned parser
- `1.4.0-dev.2664`: median 2.772 ms (min 2.335 ms, max 3.883 ms, 49 timed parses), 83.5x the owned parser
- `1.4.0-dev.2665`: median 1.278 ms (min 1.016 ms, max 3.936 ms, 49 timed parses), 38.5x the owned parser
- `1.4.0-dev.2667`: median 1.279 ms (min 0.989 ms, max 3.013 ms, 49 timed parses), 38.5x the owned parser
- `1.4.0-dev.2971`: median 1.432 ms (min 0.990 ms, max 2.812 ms, 49 timed parses), 43.1x the owned parser
- `owned-4879a44e`: median 0.033 ms (min 0.017 ms, max 0.244 ms, 49 timed parses)

Noise threshold from unchanged arms for this cell: 7.1% (nearest measured configuration, not this cell)

- `1.1.1` to `1.3.1` (before the 1.3.2 patch): 2.959 ms to 3.159 ms, 6.7%, within noise
- `1.3.1` to `1.3.2` (the 1.3.2 patch (pull 992)): 3.159 ms to 2.322 ms, -26.5%, beyond noise
- `1.3.2` to `1.3.6` (three later 1.3 maintenance releases): 2.322 ms to 2.322 ms, 0.0%, within noise
- `1.3.6` to `1.4.0-dev.2664` (last dev build before pull 997): 2.322 ms to 2.772 ms, 19.4%, beyond noise
- `1.4.0-dev.2664` to `1.4.0-dev.2665` (pull 997 (deferred diagnostics)): 2.772 ms to 1.278 ms, -53.9%, beyond noise
- `1.4.0-dev.2665` to `1.4.0-dev.2667` (the pull-997 merge commit): 1.278 ms to 1.279 ms, 0.1%, within noise
- `1.4.0-dev.2667` to `1.4.0-dev.2971` (main since 2667 up to current dev): 1.279 ms to 1.432 ms, 11.9%, beyond noise

## no-separator short 100 n=100

Measured medians, with the range of every timed sample:

- `1.1.1`: median 27.137 ms (min 25.851 ms, max 44.250 ms, 49 timed parses), 546.0x the owned parser
- `1.3.1`: median 27.560 ms (min 25.540 ms, max 36.995 ms, 49 timed parses), 554.5x the owned parser
- `1.3.2`: median 16.981 ms (min 15.777 ms, max 19.574 ms, 49 timed parses), 341.7x the owned parser
- `1.3.6`: median 17.154 ms (min 15.371 ms, max 27.624 ms, 49 timed parses), 345.1x the owned parser
- `1.4.0-dev.2664`: median 21.205 ms (min 18.832 ms, max 27.971 ms, 49 timed parses), 426.7x the owned parser
- `1.4.0-dev.2665`: median 10.935 ms (min 7.587 ms, max 17.324 ms, 49 timed parses), 220.0x the owned parser
- `1.4.0-dev.2667`: median 11.361 ms (min 7.483 ms, max 19.595 ms, 49 timed parses), 228.6x the owned parser
- `1.4.0-dev.2971`: median 10.572 ms (min 7.867 ms, max 16.213 ms, 49 timed parses), 212.7x the owned parser
- `owned-4879a44e`: median 0.050 ms (min 0.032 ms, max 0.146 ms, 49 timed parses)

Noise threshold from unchanged arms for this cell: 7.1% (nearest measured configuration, not this cell)

- `1.1.1` to `1.3.1` (before the 1.3.2 patch): 27.137 ms to 27.560 ms, 1.6%, within noise
- `1.3.1` to `1.3.2` (the 1.3.2 patch (pull 992)): 27.560 ms to 16.981 ms, -38.4%, beyond noise
- `1.3.2` to `1.3.6` (three later 1.3 maintenance releases): 16.981 ms to 17.154 ms, 1.0%, within noise
- `1.3.6` to `1.4.0-dev.2664` (last dev build before pull 997): 17.154 ms to 21.205 ms, 23.6%, beyond noise
- `1.4.0-dev.2664` to `1.4.0-dev.2665` (pull 997 (deferred diagnostics)): 21.205 ms to 10.935 ms, -48.4%, beyond noise
- `1.4.0-dev.2665` to `1.4.0-dev.2667` (the pull-997 merge commit): 10.935 ms to 11.361 ms, 3.9%, within noise
- `1.4.0-dev.2667` to `1.4.0-dev.2971` (main since 2667 up to current dev): 11.361 ms to 10.572 ms, -6.9%, within noise

## no-separator short 1000 n=1000

Measured medians, with the range of every timed sample:

- `1.1.1`: median 303.909 ms (min 285.085 ms, max 446.869 ms, 49 timed parses), 1838.5x the owned parser
- `1.3.1`: median 300.348 ms (min 287.278 ms, max 450.874 ms, 49 timed parses), 1817.0x the owned parser
- `1.3.2`: median 185.259 ms (min 169.668 ms, max 226.232 ms, 49 timed parses), 1120.7x the owned parser
- `1.3.6`: median 184.030 ms (min 170.885 ms, max 211.799 ms, 49 timed parses), 1113.3x the owned parser
- `1.4.0-dev.2664`: median 228.591 ms (min 209.546 ms, max 368.715 ms, 49 timed parses), 1382.9x the owned parser
- `1.4.0-dev.2665`: median 91.825 ms (min 84.709 ms, max 152.327 ms, 49 timed parses), 555.5x the owned parser
- `1.4.0-dev.2667`: median 90.143 ms (min 82.133 ms, max 145.989 ms, 49 timed parses), 545.3x the owned parser
- `1.4.0-dev.2971`: median 89.668 ms (min 82.749 ms, max 124.901 ms, 49 timed parses), 542.5x the owned parser
- `owned-4879a44e`: median 0.165 ms (min 0.101 ms, max 0.324 ms, 49 timed parses)

Noise threshold from unchanged arms for this cell: 7.1%

- `1.1.1` to `1.3.1` (before the 1.3.2 patch): 303.909 ms to 300.348 ms, -1.2%, within noise
- `1.3.1` to `1.3.2` (the 1.3.2 patch (pull 992)): 300.348 ms to 185.259 ms, -38.3%, beyond noise
- `1.3.2` to `1.3.6` (three later 1.3 maintenance releases): 185.259 ms to 184.030 ms, -0.7%, within noise
- `1.3.6` to `1.4.0-dev.2664` (last dev build before pull 997): 184.030 ms to 228.591 ms, 24.2%, beyond noise
- `1.4.0-dev.2664` to `1.4.0-dev.2665` (pull 997 (deferred diagnostics)): 228.591 ms to 91.825 ms, -59.8%, beyond noise
- `1.4.0-dev.2665` to `1.4.0-dev.2667` (the pull-997 merge commit): 91.825 ms to 90.143 ms, -1.8%, within noise
- `1.4.0-dev.2667` to `1.4.0-dev.2971` (main since 2667 up to current dev): 90.143 ms to 89.668 ms, -0.5%, within noise

## separator real 1 n=1

Measured medians, with the range of every timed sample:

- `1.1.1`: median 0.538 ms (min 0.350 ms, max 1.644 ms, 49 timed parses), 14.3x the owned parser
- `1.3.1`: median 0.629 ms (min 0.424 ms, max 1.889 ms, 49 timed parses), 16.7x the owned parser
- `1.3.2`: median 0.666 ms (min 0.451 ms, max 1.600 ms, 49 timed parses), 17.7x the owned parser
- `1.3.6`: median 0.705 ms (min 0.513 ms, max 1.265 ms, 49 timed parses), 18.8x the owned parser
- `1.4.0-dev.2664`: median 0.714 ms (min 0.572 ms, max 1.590 ms, 49 timed parses), 19.0x the owned parser
- `1.4.0-dev.2665`: median 0.547 ms (min 0.317 ms, max 1.761 ms, 49 timed parses), 14.5x the owned parser
- `1.4.0-dev.2667`: median 0.565 ms (min 0.319 ms, max 1.107 ms, 49 timed parses), 15.0x the owned parser
- `1.4.0-dev.2971`: median 0.548 ms (min 0.326 ms, max 1.188 ms, 49 timed parses), 14.6x the owned parser
- `owned-4879a44e`: median 0.038 ms (min 0.023 ms, max 0.066 ms, 49 timed parses)

Noise threshold from unchanged arms for this cell: 16.9% (nearest measured configuration, not this cell)

- `1.1.1` to `1.3.1` (before the 1.3.2 patch): 0.538 ms to 0.629 ms, 17.0%, beyond noise
- `1.3.1` to `1.3.2` (the 1.3.2 patch (pull 992)): 0.629 ms to 0.666 ms, 5.9%, within noise
- `1.3.2` to `1.3.6` (three later 1.3 maintenance releases): 0.666 ms to 0.705 ms, 5.9%, within noise
- `1.3.6` to `1.4.0-dev.2664` (last dev build before pull 997): 0.705 ms to 0.714 ms, 1.2%, within noise
- `1.4.0-dev.2664` to `1.4.0-dev.2665` (pull 997 (deferred diagnostics)): 0.714 ms to 0.547 ms, -23.4%, beyond noise
- `1.4.0-dev.2665` to `1.4.0-dev.2667` (the pull-997 merge commit): 0.547 ms to 0.565 ms, 3.2%, within noise
- `1.4.0-dev.2667` to `1.4.0-dev.2971` (main since 2667 up to current dev): 0.565 ms to 0.548 ms, -3.0%, within noise

## separator real 10 n=10

Measured medians, with the range of every timed sample:

- `1.1.1`: median 0.522 ms (min 0.336 ms, max 1.435 ms, 49 timed parses), 14.3x the owned parser
- `1.3.1`: median 0.625 ms (min 0.413 ms, max 2.487 ms, 49 timed parses), 17.1x the owned parser
- `1.3.2`: median 0.658 ms (min 0.510 ms, max 1.471 ms, 49 timed parses), 18.0x the owned parser
- `1.3.6`: median 0.687 ms (min 0.496 ms, max 2.342 ms, 49 timed parses), 18.8x the owned parser
- `1.4.0-dev.2664`: median 0.730 ms (min 0.551 ms, max 1.769 ms, 49 timed parses), 20.0x the owned parser
- `1.4.0-dev.2665`: median 0.532 ms (min 0.304 ms, max 1.181 ms, 49 timed parses), 14.6x the owned parser
- `1.4.0-dev.2667`: median 0.552 ms (min 0.312 ms, max 1.481 ms, 49 timed parses), 15.1x the owned parser
- `1.4.0-dev.2971`: median 0.546 ms (min 0.330 ms, max 1.332 ms, 49 timed parses), 15.0x the owned parser
- `owned-4879a44e`: median 0.036 ms (min 0.025 ms, max 0.093 ms, 49 timed parses)

Noise threshold from unchanged arms for this cell: 16.9% (nearest measured configuration, not this cell)

- `1.1.1` to `1.3.1` (before the 1.3.2 patch): 0.522 ms to 0.625 ms, 19.6%, beyond noise
- `1.3.1` to `1.3.2` (the 1.3.2 patch (pull 992)): 0.625 ms to 0.658 ms, 5.3%, within noise
- `1.3.2` to `1.3.6` (three later 1.3 maintenance releases): 0.658 ms to 0.687 ms, 4.4%, within noise
- `1.3.6` to `1.4.0-dev.2664` (last dev build before pull 997): 0.687 ms to 0.730 ms, 6.3%, within noise
- `1.4.0-dev.2664` to `1.4.0-dev.2665` (pull 997 (deferred diagnostics)): 0.730 ms to 0.532 ms, -27.1%, beyond noise
- `1.4.0-dev.2665` to `1.4.0-dev.2667` (the pull-997 merge commit): 0.532 ms to 0.552 ms, 3.7%, within noise
- `1.4.0-dev.2667` to `1.4.0-dev.2971` (main since 2667 up to current dev): 0.552 ms to 0.546 ms, -1.1%, within noise

## separator real 100 n=100

Measured medians, with the range of every timed sample:

- `1.1.1`: median 0.535 ms (min 0.346 ms, max 1.558 ms, 49 timed parses), 12.6x the owned parser
- `1.3.1`: median 0.596 ms (min 0.419 ms, max 1.836 ms, 49 timed parses), 14.1x the owned parser
- `1.3.2`: median 0.650 ms (min 0.503 ms, max 1.249 ms, 49 timed parses), 15.4x the owned parser
- `1.3.6`: median 0.689 ms (min 0.511 ms, max 1.518 ms, 49 timed parses), 16.3x the owned parser
- `1.4.0-dev.2664`: median 0.740 ms (min 0.560 ms, max 1.914 ms, 49 timed parses), 17.5x the owned parser
- `1.4.0-dev.2665`: median 0.574 ms (min 0.325 ms, max 1.184 ms, 49 timed parses), 13.6x the owned parser
- `1.4.0-dev.2667`: median 0.554 ms (min 0.312 ms, max 1.237 ms, 49 timed parses), 13.1x the owned parser
- `1.4.0-dev.2971`: median 0.545 ms (min 0.345 ms, max 1.224 ms, 49 timed parses), 12.9x the owned parser
- `owned-4879a44e`: median 0.042 ms (min 0.026 ms, max 0.120 ms, 49 timed parses)

Noise threshold from unchanged arms for this cell: 16.9% (nearest measured configuration, not this cell)

- `1.1.1` to `1.3.1` (before the 1.3.2 patch): 0.535 ms to 0.596 ms, 11.5%, within noise
- `1.3.1` to `1.3.2` (the 1.3.2 patch (pull 992)): 0.596 ms to 0.650 ms, 9.0%, within noise
- `1.3.2` to `1.3.6` (three later 1.3 maintenance releases): 0.650 ms to 0.689 ms, 6.0%, within noise
- `1.3.6` to `1.4.0-dev.2664` (last dev build before pull 997): 0.689 ms to 0.740 ms, 7.5%, within noise
- `1.4.0-dev.2664` to `1.4.0-dev.2665` (pull 997 (deferred diagnostics)): 0.740 ms to 0.574 ms, -22.5%, beyond noise
- `1.4.0-dev.2665` to `1.4.0-dev.2667` (the pull-997 merge commit): 0.574 ms to 0.554 ms, -3.5%, within noise
- `1.4.0-dev.2667` to `1.4.0-dev.2971` (main since 2667 up to current dev): 0.554 ms to 0.545 ms, -1.7%, within noise

## separator real 1000 n=1000

Measured medians, with the range of every timed sample:

- `1.1.1`: median 0.560 ms (min 0.364 ms, max 1.778 ms, 49 timed parses), 3.5x the owned parser
- `1.3.1`: median 0.672 ms (min 0.443 ms, max 2.153 ms, 49 timed parses), 4.2x the owned parser
- `1.3.2`: median 0.635 ms (min 0.521 ms, max 1.731 ms, 49 timed parses), 4.0x the owned parser
- `1.3.6`: median 0.640 ms (min 0.536 ms, max 2.154 ms, 49 timed parses), 4.0x the owned parser
- `1.4.0-dev.2664`: median 0.780 ms (min 0.573 ms, max 3.570 ms, 49 timed parses), 4.9x the owned parser
- `1.4.0-dev.2665`: median 0.639 ms (min 0.365 ms, max 1.451 ms, 49 timed parses), 4.0x the owned parser
- `1.4.0-dev.2667`: median 0.621 ms (min 0.333 ms, max 1.097 ms, 49 timed parses), 3.9x the owned parser
- `1.4.0-dev.2971`: median 0.394 ms (min 0.336 ms, max 1.410 ms, 49 timed parses), 2.5x the owned parser
- `owned-4879a44e`: median 0.160 ms (min 0.038 ms, max 0.588 ms, 49 timed parses)

Noise threshold from unchanged arms for this cell: 16.9% (nearest measured configuration, not this cell)

- `1.1.1` to `1.3.1` (before the 1.3.2 patch): 0.560 ms to 0.672 ms, 20.0%, beyond noise
- `1.3.1` to `1.3.2` (the 1.3.2 patch (pull 992)): 0.672 ms to 0.635 ms, -5.5%, within noise
- `1.3.2` to `1.3.6` (three later 1.3 maintenance releases): 0.635 ms to 0.640 ms, 0.9%, within noise
- `1.3.6` to `1.4.0-dev.2664` (last dev build before pull 997): 0.640 ms to 0.780 ms, 21.8%, beyond noise
- `1.4.0-dev.2664` to `1.4.0-dev.2665` (pull 997 (deferred diagnostics)): 0.780 ms to 0.639 ms, -18.1%, beyond noise
- `1.4.0-dev.2665` to `1.4.0-dev.2667` (the pull-997 merge commit): 0.639 ms to 0.621 ms, -2.7%, within noise
- `1.4.0-dev.2667` to `1.4.0-dev.2971` (main since 2667 up to current dev): 0.621 ms to 0.394 ms, -36.5%, beyond noise

## separator short 1 n=1

Measured medians, with the range of every timed sample:

- `1.1.1`: median 0.560 ms (min 0.333 ms, max 1.935 ms, 49 timed parses), 12.1x the owned parser
- `1.3.1`: median 0.691 ms (min 0.419 ms, max 1.985 ms, 49 timed parses), 15.0x the owned parser
- `1.3.2`: median 0.884 ms (min 0.518 ms, max 1.920 ms, 49 timed parses), 19.2x the owned parser
- `1.3.6`: median 0.634 ms (min 0.521 ms, max 1.771 ms, 49 timed parses), 13.8x the owned parser
- `1.4.0-dev.2664`: median 0.849 ms (min 0.562 ms, max 1.918 ms, 49 timed parses), 18.4x the owned parser
- `1.4.0-dev.2665`: median 0.537 ms (min 0.315 ms, max 0.969 ms, 49 timed parses), 11.7x the owned parser
- `1.4.0-dev.2667`: median 0.576 ms (min 0.309 ms, max 1.841 ms, 49 timed parses), 12.5x the owned parser
- `1.4.0-dev.2971`: median 0.575 ms (min 0.339 ms, max 1.272 ms, 49 timed parses), 12.5x the owned parser
- `owned-4879a44e`: median 0.046 ms (min 0.021 ms, max 0.074 ms, 49 timed parses)

Noise threshold from unchanged arms for this cell: 16.9% (nearest measured configuration, not this cell)

- `1.1.1` to `1.3.1` (before the 1.3.2 patch): 0.560 ms to 0.691 ms, 23.3%, beyond noise
- `1.3.1` to `1.3.2` (the 1.3.2 patch (pull 992)): 0.691 ms to 0.884 ms, 28.0%, beyond noise
- `1.3.2` to `1.3.6` (three later 1.3 maintenance releases): 0.884 ms to 0.634 ms, -28.3%, beyond noise
- `1.3.6` to `1.4.0-dev.2664` (last dev build before pull 997): 0.634 ms to 0.849 ms, 33.9%, beyond noise
- `1.4.0-dev.2664` to `1.4.0-dev.2665` (pull 997 (deferred diagnostics)): 0.849 ms to 0.537 ms, -36.7%, beyond noise
- `1.4.0-dev.2665` to `1.4.0-dev.2667` (the pull-997 merge commit): 0.537 ms to 0.576 ms, 7.1%, within noise
- `1.4.0-dev.2667` to `1.4.0-dev.2971` (main since 2667 up to current dev): 0.576 ms to 0.575 ms, -0.1%, within noise

## separator short 10 n=10

Measured medians, with the range of every timed sample:

- `1.1.1`: median 0.622 ms (min 0.335 ms, max 1.677 ms, 49 timed parses), 18.2x the owned parser
- `1.3.1`: median 0.628 ms (min 0.406 ms, max 2.139 ms, 49 timed parses), 18.4x the owned parser
- `1.3.2`: median 0.780 ms (min 0.490 ms, max 2.161 ms, 49 timed parses), 22.8x the owned parser
- `1.3.6`: median 0.629 ms (min 0.494 ms, max 1.775 ms, 49 timed parses), 18.4x the owned parser
- `1.4.0-dev.2664`: median 0.840 ms (min 0.550 ms, max 1.671 ms, 49 timed parses), 24.6x the owned parser
- `1.4.0-dev.2665`: median 0.560 ms (min 0.322 ms, max 1.592 ms, 49 timed parses), 16.4x the owned parser
- `1.4.0-dev.2667`: median 0.550 ms (min 0.311 ms, max 2.370 ms, 49 timed parses), 16.1x the owned parser
- `1.4.0-dev.2971`: median 0.573 ms (min 0.346 ms, max 1.308 ms, 49 timed parses), 16.7x the owned parser
- `owned-4879a44e`: median 0.034 ms (min 0.023 ms, max 0.079 ms, 49 timed parses)

Noise threshold from unchanged arms for this cell: 16.9% (nearest measured configuration, not this cell)

- `1.1.1` to `1.3.1` (before the 1.3.2 patch): 0.622 ms to 0.628 ms, 0.9%, within noise
- `1.3.1` to `1.3.2` (the 1.3.2 patch (pull 992)): 0.628 ms to 0.780 ms, 24.3%, beyond noise
- `1.3.2` to `1.3.6` (three later 1.3 maintenance releases): 0.780 ms to 0.629 ms, -19.4%, beyond noise
- `1.3.6` to `1.4.0-dev.2664` (last dev build before pull 997): 0.629 ms to 0.840 ms, 33.6%, beyond noise
- `1.4.0-dev.2664` to `1.4.0-dev.2665` (pull 997 (deferred diagnostics)): 0.840 ms to 0.560 ms, -33.3%, beyond noise
- `1.4.0-dev.2665` to `1.4.0-dev.2667` (the pull-997 merge commit): 0.560 ms to 0.550 ms, -1.8%, within noise
- `1.4.0-dev.2667` to `1.4.0-dev.2971` (main since 2667 up to current dev): 0.550 ms to 0.573 ms, 4.1%, within noise

## separator short 100 n=100

Measured medians, with the range of every timed sample:

- `1.1.1`: median 0.639 ms (min 0.344 ms, max 1.766 ms, 49 timed parses), 15.5x the owned parser
- `1.3.1`: median 0.581 ms (min 0.411 ms, max 1.855 ms, 49 timed parses), 14.1x the owned parser
- `1.3.2`: median 0.965 ms (min 0.483 ms, max 2.413 ms, 49 timed parses), 23.4x the owned parser
- `1.3.6`: median 0.631 ms (min 0.485 ms, max 2.053 ms, 49 timed parses), 15.3x the owned parser
- `1.4.0-dev.2664`: median 0.884 ms (min 0.562 ms, max 2.569 ms, 49 timed parses), 21.4x the owned parser
- `1.4.0-dev.2665`: median 0.569 ms (min 0.318 ms, max 1.241 ms, 49 timed parses), 13.8x the owned parser
- `1.4.0-dev.2667`: median 0.539 ms (min 0.317 ms, max 1.016 ms, 49 timed parses), 13.1x the owned parser
- `1.4.0-dev.2971`: median 0.572 ms (min 0.361 ms, max 1.228 ms, 49 timed parses), 13.9x the owned parser
- `owned-4879a44e`: median 0.041 ms (min 0.023 ms, max 0.090 ms, 49 timed parses)

Noise threshold from unchanged arms for this cell: 16.9% (nearest measured configuration, not this cell)

- `1.1.1` to `1.3.1` (before the 1.3.2 patch): 0.639 ms to 0.581 ms, -9.1%, within noise
- `1.3.1` to `1.3.2` (the 1.3.2 patch (pull 992)): 0.581 ms to 0.965 ms, 66.2%, beyond noise
- `1.3.2` to `1.3.6` (three later 1.3 maintenance releases): 0.965 ms to 0.631 ms, -34.6%, beyond noise
- `1.3.6` to `1.4.0-dev.2664` (last dev build before pull 997): 0.631 ms to 0.884 ms, 39.9%, beyond noise
- `1.4.0-dev.2664` to `1.4.0-dev.2665` (pull 997 (deferred diagnostics)): 0.884 ms to 0.569 ms, -35.6%, beyond noise
- `1.4.0-dev.2665` to `1.4.0-dev.2667` (the pull-997 merge commit): 0.569 ms to 0.539 ms, -5.2%, within noise
- `1.4.0-dev.2667` to `1.4.0-dev.2971` (main since 2667 up to current dev): 0.539 ms to 0.572 ms, 6.0%, within noise

## separator short 1000 n=1000

Measured medians, with the range of every timed sample:

- `1.1.1`: median 0.649 ms (min 0.373 ms, max 1.910 ms, 49 timed parses), 3.8x the owned parser
- `1.3.1`: median 0.623 ms (min 0.432 ms, max 1.751 ms, 49 timed parses), 3.7x the owned parser
- `1.3.2`: median 0.815 ms (min 0.491 ms, max 1.923 ms, 49 timed parses), 4.8x the owned parser
- `1.3.6`: median 0.722 ms (min 0.508 ms, max 1.708 ms, 49 timed parses), 4.3x the owned parser
- `1.4.0-dev.2664`: median 0.825 ms (min 0.581 ms, max 2.032 ms, 49 timed parses), 4.9x the owned parser
- `1.4.0-dev.2665`: median 0.692 ms (min 0.376 ms, max 1.134 ms, 49 timed parses), 4.1x the owned parser
- `1.4.0-dev.2667`: median 0.700 ms (min 0.379 ms, max 1.033 ms, 49 timed parses), 4.1x the owned parser
- `1.4.0-dev.2971`: median 0.622 ms (min 0.336 ms, max 1.112 ms, 49 timed parses), 3.7x the owned parser
- `owned-4879a44e`: median 0.170 ms (min 0.039 ms, max 1.277 ms, 49 timed parses)

Noise threshold from unchanged arms for this cell: 16.9% (nearest measured configuration, not this cell)

- `1.1.1` to `1.3.1` (before the 1.3.2 patch): 0.649 ms to 0.623 ms, -3.9%, within noise
- `1.3.1` to `1.3.2` (the 1.3.2 patch (pull 992)): 0.623 ms to 0.815 ms, 30.8%, beyond noise
- `1.3.2` to `1.3.6` (three later 1.3 maintenance releases): 0.815 ms to 0.722 ms, -11.4%, within noise
- `1.3.6` to `1.4.0-dev.2664` (last dev build before pull 997): 0.722 ms to 0.825 ms, 14.3%, within noise
- `1.4.0-dev.2664` to `1.4.0-dev.2665` (pull 997 (deferred diagnostics)): 0.825 ms to 0.692 ms, -16.1%, within noise
- `1.4.0-dev.2665` to `1.4.0-dev.2667` (the pull-997 merge commit): 0.692 ms to 0.700 ms, 1.1%, within noise
- `1.4.0-dev.2667` to `1.4.0-dev.2971` (main since 2667 up to current dev): 0.700 ms to 0.622 ms, -11.1%, within noise

