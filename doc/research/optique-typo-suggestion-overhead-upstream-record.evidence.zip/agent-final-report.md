All data is in, and the scratch tree is clean (no containers or processes of mine left running). Final report:

# Optique commit-parser measurement, 2026-11-12

## What ran, and where

Everything lives in `${HOME}/temp/agent/optique-measure-2026-11-12/` (mode 700). The repository was not edited or committed; the five modified files `git status` shows are another session's work and I did not touch them.

- Image: `localhost/optique-measure:2026-11-12`, id `e41ee2dfe04c…c4505c`, base `docker.io/cachyos/cachyos-v4:latest` (`sha256:1dcd1350f4b8…8c370`) as `doc/decision/container-base-distro.md` requires.
- Node inside the image: v26.13.1 (`nodejs 26.13.1-2`, `npm 12.2.2`), identical to the host's.
- Container limits: `--cpus 2 --memory 4g --pids-limit 512 --blkio-weight 10 --rm`, no mounts, results on stdout.
- Host: 32 CPUs, but this session's cgroup is `cpu.max 300000/100000` (3 CPUs) and `memory.max` 6 GiB. Load average during the runs stayed between 29 and 42; I never waited for a quiet host (rule `NQH`).
- Wall clock of the full run: 14:46:01Z to 15:05:51Z, 1064 timed executions plus 384 spread and 9 behaviour processes.

## The two commands

Rebuild the image:

```
cd -- /home/user/temp/agent/optique-measure-2026-11-12 && podman build --tag localhost/optique-measure:2026-11-12 --file Containerfile .
```

Rerun the whole measurement (four container experiments, then the four host analyses):

```
cd -- /home/user/temp/agent/optique-measure-2026-11-12 && node scripts/measure.ts
```

## Raw results

- `results/runs.jsonl`: 1064 run records (one per fresh process: warmup 2, then 7 timed parses, plus a validation record).
- `results/spread.jsonl`: 384 records of the unchanged arms.
- `results/behaviour.jsonl`: `results/behavior.jsonl`, 287 records: the exact fact record per arm per input, plus the two upstream reproductions.
- `results/profiles.jsonl`: four `node --cpu-prof` analyses.
- `results/summary.json`, `results/spread-summary.json`, `results/behavior-comparison.json`, `results/report-tables.md`: derived tables with every min, max, per-round median and digest.
- `results/run-meta.json`: image id, limits, round settings, timestamps.
- `ctx/meta.json`: tarball digests, npm publish times, JSR source commits, deferred-failure evidence per version.

## The slowness reproduces, and the shape is edit distance

`parseCommitRegion(['--message','x', ...1000 real paths])` on `@optique/core` 1.1.1: median **2695.663 ms** (min 2574.641, max 3898.915, 49 timed parses). That is the same order as the historical 2.56 s, which was wrapper-pipeline time, not parse-only time. The 1.3.1 arm is identical (2706.689 ms, +0.4%, within the spread).

Cost is linear in path count times path length, which is the signature of per-token edit distance. On 1.1.1 the per-character cost is flat:

- 10 paths (mean 40.8 chars): 21.479 ms, 0.053 ms per path-character
- 100 paths (mean 28.3 chars): 150.104 ms, 0.053 ms per path-character
- 1000 paths (mean 53.5 chars): 2695.663 ms, 0.050 ms per path-character

Per-path cost alone looks non-monotonic (2.15, 1.50, 2.70 ms per path) only because the real-path prefixes differ in length. Real paths are the tracked files at `1e53f52e02` (the parent of `4879a44e6a`), first 1000 in tree order: min 9 chars, median 55, max 104. The short set is 1 to 3 character names (mean 2.3 at 1000).

## Measured spread of an unchanged arm

Eight independent copies of the same configuration, interleaved over six rounds, each copy a fresh process:

- `1.3.6`, 1000 real paths, no separator: copy medians 183.7 to 190.3 ms, range 3.6%, sd 5.6 ms
- `1.4.0-dev.2971`, same cell: 90.0 to 100.2 ms, range 11.0%, sd 5.4 ms
- `1.3.6`, 100 real paths: range 9.7%; 10 paths: 15.5%; 1 path: 16.9% (0.89 to 1.05 ms)
- `1.3.6`, 1000 short paths: range 7.1%
- `1.3.6`, issue-988 parser: range 5.0%
- `owned-4879a44e`, 1000 real paths: range 15.2%, but its absolute range is 0.0265 ms

So differences below roughly 11% at thousand-path scale, and below roughly 17% at single-path scale, are noise. Every verdict below stays the same under either bound; the only changes near the line are 1.3.2 to 1.3.6 (+2.4%) and 2665 to 2667 (+7.3%), both inside noise.

## Medians per version and workload

Nine arms. `1.4.0-dev.2664` is the extra arm I added (see departures); `owned-4879a44e` is the repository-owned parser. Median over 49 timed parses per arm and cell.

### No separator, real paths, 1000 (the workload that caused the migration)

- `1.1.1`: 2695.663 ms (min 2574.641, max 3898.915), 15282x owned
- `1.3.1`: 2706.689 ms (min 2570.456, max 2985.197), 15344x
- `1.3.2`: 180.033 ms (min 166.344, max 206.032), 1021x
- `1.3.6`: 184.275 ms (min 172.846, max 228.530), 1045x
- `1.4.0-dev.2664`: 229.046 ms (min 206.594, max 294.573), 1298x
- `1.4.0-dev.2665`: 90.195 ms (min 80.496, max 115.034), 511x
- `1.4.0-dev.2667`: 96.813 ms (min 84.447, max 114.766), 549x
- `1.4.0-dev.2971`: 94.962 ms (min 83.552, max 242.640), 538x
- `owned-4879a44e`: 0.176 ms (min 0.089, max 1.319)

Adjacent-release deltas: 1.1.1 to 1.3.1 +0.4% (noise); 1.3.1 to 1.3.2 **-93.3%**; 1.3.2 to 1.3.6 +2.4% (noise); 1.3.6 to 2664 **+24.3%**; 2664 to 2665 **-60.6%**; 2665 to 2667 +7.3% (noise); 2667 to 2971 -1.9% (noise).

Growth across counts (median ms), same workload:

- 1 path: 2.749, 2.997, 0.867, 1.025, 1.089, 0.791, 0.743, 0.526, owned 0.038
- 10 paths: 21.479, 21.770, 2.658, 2.486, 3.457, 1.685, 1.700, 2.146, owned 0.032
- 100 paths: 150.104, 151.129, 24.898, 23.414, 27.585, 9.624, 10.410, 10.389, owned 0.050
- (values in arm order: 1.1.1, 1.3.1, 1.3.2, 1.3.6, 2664, 2665, 2667, 2971, owned)

### No separator, short paths, 1000

- `1.1.1`: 303.909 ms (min 285.085, max 446.869), 1839x owned
- `1.3.1`: 300.348 ms (min 287.278, max 450.874), 1817x
- `1.3.2`: 185.259 ms (min 169.668, max 226.232), 1121x
- `1.3.6`: 184.030 ms (min 170.885, max 211.799), 1113x
- `1.4.0-dev.2664`: 228.591 ms (min 209.546, max 368.715), 1383x
- `1.4.0-dev.2665`: 91.825 ms (min 84.709, max 152.327), 556x
- `1.4.0-dev.2667`: 90.143 ms (min 82.133, max 145.989), 545x
- `1.4.0-dev.2971`: 89.668 ms (min 82.749, max 124.901), 543x
- `owned-4879a44e`: 0.165 ms (min 0.101, max 0.324)

Deltas: 1.1.1 to 1.3.1 -1.2% (noise); 1.3.1 to 1.3.2 **-38.3%**; 1.3.2 to 1.3.6 -0.7% (noise); 1.3.6 to 2664 **+24.2%**; 2664 to 2665 **-59.8%**; 2665 to 2667 -1.8% (noise); 2667 to 2971 -0.5% (noise). Counts 1, 10, 100: 1.1.1 0.737/2.960/27.137, 1.3.1 0.856/3.159/27.560, 1.3.2 0.972/2.322/16.981, 1.3.6 0.911/2.322/17.154, 2664 1.032/2.772/21.205, 2665 0.803/1.278/10.935, 2667 0.741/1.279/11.361, 2971 0.784/1.432/10.573, owned 0.040/0.033/0.050.

### Issue 988 reproduction, 1000 long distinct paths, 30 options

- `1.1.1`: 964.256 ms (min 924.540, max 1299.860)
- `1.3.1`: 952.035 ms (min 895.359, max 1211.733)
- `1.3.2`: 111.092 ms (min 98.691, max 150.827)
- `1.3.6`: 109.276 ms (min 97.157, max 172.948)
- `1.4.0-dev.2664`: 147.783 ms (min 130.492, max 218.479)
- `1.4.0-dev.2665`: 83.019 ms (min 73.744, max 104.579)
- `1.4.0-dev.2667`: 80.300 ms (min 74.401, max 110.914)
- `1.4.0-dev.2971`: 86.209 ms (min 72.363, max 145.752)
- owned parser: not run, the reproduction is written against Optique's API

Against upstream's own bench (1,736 ms to 167 ms for pull 992, then 112 ms to 65 ms for pull 997), my ratios are close (8.6x, then 1.8x from the pull-997 base) but the absolute values differ because of the hardware and the container cap.

### Control: paths after `--`

Region handed to Optique is only `['--message','x']`, so this must stay flat, and it does, across all four counts and both path sets: 0.52 to 0.74 ms for every Optique arm, 0.034 to 0.046 ms for the owned parser. At 1000 paths the version-independent scanner still walks every token, so the cell costs 0.5 to 0.95 ms in total. The point that matters: the Optique parse alone adds roughly 0.5 ms per invocation over the owned parser even when it sees three tokens, and no version changes that.

## What the profile attributes the time to

`node --cpu-prof --cpu-prof-interval=100` on the 1000-real-path no-separator workload, sampling interval about 0.16 ms, self times inside the parse call tree.

1.1.1, 3 parses, 10,825 ms in parse:

- `levenshteinDistance` (`suggestion.js`) 93.1% self
- `findSimilar` 1.8%, `createErrorWithSuggestions` 1.4%, `traverseUsage` 1.4%, `set` (`input-trace.js`) 0.8%
- suggestion or edit-distance functions total **96.4%** of the parse; `suggestion.js` alone 96.4%

1.3.6, 40 parses, 7,151 ms in parse:

- `traverseUsage` (`usage.js`) 23.7%, `findSimilar` 21.0%, `createErrorWithSuggestions` 20.1%, `set` (`input-trace.js`) 10.5%, `levenshteinDistance` 5.6%, `extractOptionNames` 3.6%
- suggestion or edit-distance functions total **46.6%**; `suggestion.js` 46.6%, `usage.js` 27.3%, `input-trace.js` 10.7%

1.4.0-dev.2971, 40 parses, 3,449 ms in parse:

- `set` (`input-trace.js`) 22.9%, `withParserOptionScope` 9.1%, `createDeferredFailure` 8.3%, `withOptionScopeChild` 7.7%, anonymous `constructs.js` 7.0%, `forkOptionScope` 6.8%
- suggestion or edit-distance functions total **0.0%**; `short-option.js` 31.3%, `input-trace.js` 23.3%, `constructs.js` 14.2%, `failure.js` 8.3%

Owned parser (extra, not asked for), 40 parses, 4.8 ms in parse (coarse sampling, only 328 samples):

- `extractCommitPathspecs` 24.1%, `normaliseCommitArgs` 18.9%, `parseCommitRegion` 12.7%, `scanRegion` (`argv.ts`) 11.7%
- no Optique, no suggestion code; `commit-normalise.ts` 62.5%, `argv.ts` 21.6%

So the 992 patch removed 94% of the edit distance and left the suggestion machinery plus usage traversal in place; 997 removed the remaining suggestion work entirely and what is left in 2971 is bookkeeping around option scoping and input tracing.

## What each pre-release contains

Confirmed from the installed files, and cross-checked with JSR's commit-bearing version strings and the npm tarball digests in `ctx/meta.json`. npm's own metadata has no `gitHead` for any of them.

- `1.4.0-dev.2664` = JSR `1.4.0-dev.2664+6f258296`, the commit pull 997 was based on: **no** `dist/internal/failure.js`, **no** `createDeferredFailure` anywhere in `dist/`. This is the real "before pull 997" build.
- `1.4.0-dev.2665` = `+868a9d77`, pull 997's own head commit: `dist/internal/failure.js` present (1756 bytes, sha256 `505d55d2e41b6fbf…`), `createDeferredFailure` referenced 8 times in `constructs.js`, 3 in `primitives.js`, `withConsumedDepth` twice.
- `1.4.0-dev.2667` = `+68b5edd1`, the merge commit: the whole package is **byte-identical to 2665** except the `version` field in `package.json`. Same `failure.js` digest, same use counts.
- `1.4.0-dev.2971` = `+1d6e4594`, current `dev`: same `failure.js` (identical digest), same use counts, plus new modules (`internal/usage.js`, `help-request`, `empty-input`, `doc-metadata`, `terminal-separators`).

Your correction is confirmed independently by the tarballs: 2665 was built from the pull request branch, so it is not a "before" arm. That is why 2664 exists.

## Behaviour: identical everywhere it is timed, different for the owned parser

For every one of the 17 timed cells, all arms that ran the cell returned exactly the same `CommitRegion` record, digests included: 17 of 17 cells show `distinctResults=1`, and all 1064 timed records validate (`ok=true`, full path count). The behavior probe adds 15 option-shaped inputs, and there the only differences are the baseline:

- `['--unknown=v','a.txt']`: every Optique version returns `hasPathspec=true, pathspecs=["a.txt"]`; `owned-4879a44e` **throws** `ArgvParseError: Undeclared joined option --unknown names no known option, and cannot be read as a path either.`
- `['--unknown=v','--amend','a.txt']`: same split, Optique returns `hasAmendFlag=true, pathspecs=["a.txt"]`, owned throws the same error.
- `['--message']`: Optique returns `hasPathspec=false, pathspecs=[]`; owned throws `ArgvParseError: Option --message takes a value, but the region ends here.`
- `['-m']`: Optique returns `hasPathspec=false, pathspecs=[]`; owned throws `ArgvParseError: Option -m takes a value, but the region ends here.`

The other eleven option cases agree between all nine arms: `--unknown v a.txt`, `-q a.txt`, `--message=hello a.txt`, `--message= a.txt`, `-m a.txt`, `-am hello a.txt`, `--no-enforce-only a.txt`, `--pathspec-from-file=list.txt`, `-- a.txt`, `-- --unknown=v a.txt`, `--amend a.txt`.

Why 990/991 changed nothing in the wrapper's output: probing the two upstream reproductions directly inside each arm shows the library did change, and exactly at 1.3.2. On 1.1.1 and 1.3.1, `['--unknown=v','a.txt']` yields `paths=["--unknown=v","a.txt"], extra=[]` and `['-m']` yields `success=true, extra=["-m"]`; on 1.3.2 and later, the joined token goes to pass-through (`paths=["a.txt"], extra=["--unknown=v"]`) and a missing value becomes `success=false`. The old commit parser never reads Optique's `positionals` and treats a failed parse as an all-false record, so both behaviours collapse to the same `CommitRegion`. The owned parser instead rejects those argv shapes by throwing, which is a real behaviour change of the migration, not a timing change.

## Where I departed from the suggested design

- **Added `1.4.0-dev.2664`** as an arm. Without it, pull 997 could not be measured at all, because 2665 already ships it.
- **Added the `owned-4879a44e` baseline** (your later request): `commit.ts`, `argv.ts`, `commit-normalise.ts`, `commit-flag-aliases.ts`, `escape-hatch.ts`, `abbrev.ts` from `4879a44e6a` itself, unchanged, plus `valibot` 1.4.2 (the version `pnpm-lock.yaml` at that commit resolves, tarball digest `sha512-gjdCvJ6d3RyH…`). The four files shared with the parent commit are byte-identical, so only `commit.ts` and `argv.ts` differ between the two arms.
- **Warmup 2, timed 7, rounds 7**, not 3 and 11: the two slow arms cost about 25 s per execution at 1000 paths, and 49 timed parses per cell gave stable medians (per-round median spread is in `summary.json`). Every arm and cell still ran in a fresh process, and arms were rotated within each round (arms rotate by 3 positions per round, cells by 1) so host drift cancels.
- **Spread measured on eight configurations**, not one: real 1, 10, 100 and 1000 paths, short 1000, issue 988, `1.3.6` at 1000 paths twice under different version labels (`1.3.6` and `1.4.0-dev.2971`), and the owned parser, each as eight independent copies over six rounds. One configuration would not have bounded the small-count and short-path cells.
- **Issue 988 measured only at 1000 paths**, matching upstream's own bench, instead of across the growth curve.
- **Behaviour probe added** (your later request) with a throw branch, because the owned parser throws where Optique returns facts.
- **Profiling** used `node --cpu-prof` as asked, analysed inside the same container, plus the owned parser as a fourth profile (informative, though its 4.8 ms parse is at the sampling floor and I do not lean on it).
- **The parser sources are copied per arm** instead of symlinked, because Node resolves bare specifiers from a module's real path, so a symlinked `src/` would have picked up one shared `node_modules` for all arms. Import paths are untouched; `src/` and `ctx/owned/src/` are byte-identical to `git show`.
- **Timed calls reuse one argv array** per process; the parser does not mutate it, and the validation digest after every run would have caught it if it did.

## Could not do, and surprises

- npm carries no source commit for the dev builds; I could not have established 2665's provenance from npm alone. JSR's version strings plus the byte-identical 2665/2667 trees settle it.
- I cannot place these absolute numbers beside upstream's on equal footing: they measured 1,736/167/112/65 ms on their machine, mine are 2695/180/229/90 ms on three capped CPUs under load 29 to 42. Only the within-run comparisons are evidence.
- Only 1.3.1 to 1.3.2 is a version difference that dwarfs everything else (-93% at 1000 real paths). Pull 997 matters, but it is not the same order of magnitude (-61%).
- **Surprise:** the 1.3.2 patch does help short paths here, by 38% at 1000 short paths, contradicting pull 992's note that short-path runs showed no improvement. The mechanism is visible in `suggestion.js`: 1.3.2 skips candidates whose length difference already exceeds the threshold, and in this parser the candidates are option names (`--pathspec-from-file`, `--inter-hunk-context`) while the tokens are 1 to 3 characters, so the prefilter fires. Upstream's short-path bench presumably compared short inputs with short candidates.
- **Surprise:** `1.4.0-dev.2664` (main at pull 997's base) is 24% *slower* than 1.3.6 on both path sets, so pull 997 more than recovered an intervening regression rather than just shaving overhead.
- **Surprise:** even the best version, `1.4.0-dev.2971`, still costs about 95 ms at 1000 real paths, roughly 540x the owned parser's 0.18 ms, and about 0.53 to 0.78 ms per invocation on the three-token control, roughly 15x the owned parser's 0.04 ms. Upstream's "no suggestion work left" is true and still leaves this gap.
